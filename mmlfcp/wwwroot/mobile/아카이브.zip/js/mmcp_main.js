const BASE_URL = "/";
const API_LOADING = "api/Mobile-Auth";
const API_PRODUCT_PREMIUMS = "api/ProductPremiums";
const MOBILE_TOKEN_KEY = "mmlfcp_auth_token";


var state =
{

    plans: [],
    upload_date: {},

    productsGroupList: [],
    paymentExpirationList: [],
    mmcpPlanList: [],
    mmcpUploadDate: [],
    guide_bojang_item: new Map(),

    //초기 데이터
    jwt: "",
    cust_name: "홍길동",
    insur_age: 0,
    gender: "M",
    birth_date: "19850101",
    PlanID: "",


    prdt_cd: "11",
    expiration_cd: "4",
    use_display_yn: "N", //기본값  N으로 고정

    bojangGuideList: [],
    ProductList: [],
    insurProductList: [],


    plan_coverages: [],
    coverage_premiums: [],
    product_insur_premiums: [],


    plan_id: '000000111041', //
    plan_type: '06', //상품유형코드
    plan_name: "손보 종합(무해지)", //상품유형명
    insurance_type: 'F', //생손보유형

    plan_payterm_type: '01', //만기유형코드
    plan_payterm_type_name: "20년/100세", //만기유형명
    checked_val: "전체",


    /** URL/session 토큰 확보 후 주소창에서 token 제거 */
    resolveAuthToken: function () {
        let token = app._getUrlParameter("token");
        if (!token || token === true) {
            try {
                token = sessionStorage.getItem(MOBILE_TOKEN_KEY) || "";
            } catch (_) {
                token = "";
            }
        } else {
            try {
                sessionStorage.setItem(MOBILE_TOKEN_KEY, token);
            } catch (_) { /* ignore */ }
            try {
                const u = new URL(window.location.href);
                if (u.searchParams.has("token")) {
                    u.searchParams.delete("token");
                    const next = u.pathname + (u.searchParams.toString() ? `?${u.searchParams.toString()}` : "") + u.hash;
                    history.replaceState(history.state, "", next);
                }
            } catch (_) { /* ignore */ }
        }
        this.jwt = token || "";
        return this.jwt;
    },

    /** 여성 전용 상품 (남성일 때 목록 제외) */
    isFemaleOnlyPlan: function (plan) {
        const type = String(plan?.plan_type ?? "");
        if (type === "08") return true;
        const name = String(plan?.plan_name || "").trim();
        return /^손보\s*여성|^생보\s*여성|^여성/.test(name);
    },

    init: async function () {
        const token = this.resolveAuthToken();
        if (!token) {
            alert("인증 토큰이 없습니다. 다시 접속해 주세요.");
            return;
        }

        const url = new URL(BASE_URL + API_LOADING, window.location.origin);
        url.searchParams.append("token", token);
        url.searchParams.append("access_path", "MMLFCP_MOBILE");
        url.searchParams.append("device", "MOBILE");
        this.show_spinner();

        try {
            const response = await fetch(url, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Accept": "application/json"
                }
            });
            const data = await response.json();
            if (data.is_success === true) {
                this.set_calculate_age();
                this.setPlanList(data.plans, data.upload_date);
                await this.onClickSearch();
            } else {
                alert(data.message || data.error_message || "데이터 로드에 실패했습니다.");
            }

        } catch (error) {
            console.error("Fetch Error:", error);
            alert("서버 연결에 실패했거나 응답을 처리할 수 없습니다.");
        } finally {
            this.hide_spinner();
        }
    },

    onClickSearch: async function () {
        const token = this.jwt || this.resolveAuthToken();
        if (!token) {
            alert("인증 토큰이 없습니다. 다시 로그인해주세요.");
            return;
        }

        if (!app._isValidDate(this.birth_date)) {
            alert("생년월일을 확인해주세요.");
            return;
        }

        this.set_calculate_age();
        this.setPlanIdByCurrentState();

        const url = new URL(BASE_URL + API_PRODUCT_PREMIUMS, window.location.origin);
        url.searchParams.append("plan_id", this.plan_id);
        url.searchParams.append("insurance_type", this.insurance_type);
        url.searchParams.append("age", String(this.insur_age));
        url.searchParams.append("gender", this.gender);
        this.show_spinner();

        try {
            const response = await fetch(url, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Accept": "application/json"
                }
            });

            if (!response.ok) {
                throw new Error(`조회 요청 실패 (${response.status})`);
            }

            const data = await response.json();
            const hasCoverages = Array.isArray(data.plan_coverages) && data.plan_coverages.length > 0;
            const hasPremiums = Array.isArray(data.coverage_premiums) && data.coverage_premiums.length > 0;

            if (data.is_success === true && hasCoverages && hasPremiums) {
                this.setCoverageProductList(data);
                this.sync_menu_display();
                this.renderPremiumAsc();
            } else {
                alert(data.error_message || data.message || "조회된 상품이 없습니다.");
                this.reset_menu();
            }

        } catch (error) {
            console.error("Fetch Error:", error.message);
            alert(error.message || "조회 중 오류가 발생했습니다.");
            this.reset_menu();
        }
        finally {
            this.hide_spinner();
        }
    },


    set_calculate_age: function () {
        const birthEl = document.getElementById("birth_date");
        if (birthEl && birthEl.value) {
            this.birth_date = String(birthEl.value).replace(/\D/g, "").slice(0, 8);
        }
        this.insur_age = app._insu_age(this.birth_date);
        $(".old-view-box").text("보험나이 : " + this.insur_age + "세");
        this.syncBirthDatePicker();
    },

    /** 텍스트 생년월일 → (레거시) date picker 동기화 — 커스텀 모달 사용으로 no-op 유지 */
    syncBirthDatePicker: function () {
        // custom modal reads state.birth_date on open
    },

    /** 생년월일 적용 (텍스트/캘린더 공통) */
    applyBirthDateValue: function (rawValue, options = {}) {
        const birth_date = app._toYyyymmdd(rawValue) || String(rawValue || "").replace(/\D/g, "").slice(0, 8);
        const birthEl = document.getElementById("birth_date");
        if (birthEl) {
            birthEl.value = birth_date;
            birthEl.setAttribute("value", birth_date);
        }

        this.birth_date = birth_date;
        this.reset_menu();
        this.set_calculate_age();
        this.setProductsGroupCD();

        if (options.autoSearch !== false && birth_date.length === 8 && app._isValidDate(birth_date)) {
            this.scheduleAutoSearch({ delay: options.delay ?? 280 });
        }
    },

    _calendarView: { year: 1985, month: 0, selectedYmd: "19850101", yearPickerOpen: false },
    _calendarYearMin: 1920,
    _calendarYearMax: 2026,

    openBirthCalendar: function () {
        const modal = document.getElementById("birth_calendar_modal");
        if (!modal) return;

        const ymd = app._toYyyymmdd(this.birth_date) || "19850101";
        const y = parseInt(ymd.slice(0, 4), 10);
        const m = parseInt(ymd.slice(4, 6), 10) - 1;
        this._calendarView = {
            year: y,
            month: m,
            selectedYmd: app._isValidDate(ymd) ? ymd : "19850101",
            yearPickerOpen: false
        };
        this.setBirthCalendarYearPicker(false);
        this.renderBirthCalendar();
        modal.hidden = false;
        modal.setAttribute("aria-hidden", "false");
        document.body.classList.add("birth-calendar-open");
    },

    closeBirthCalendar: function () {
        const modal = document.getElementById("birth_calendar_modal");
        if (!modal) return;
        this.setBirthCalendarYearPicker(false);
        modal.hidden = true;
        modal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("birth-calendar-open");
    },

    shiftBirthCalendarMonth: function (delta) {
        if (this._calendarView.yearPickerOpen) {
            this.setBirthCalendarYearPicker(false);
        }
        let { year, month } = this._calendarView;
        month += delta;
        if (month < 0) {
            month = 11;
            year -= 1;
        } else if (month > 11) {
            month = 0;
            year += 1;
        }
        if (year < this._calendarYearMin || year > this._calendarYearMax) return;
        this._calendarView.year = year;
        this._calendarView.month = month;
        this.renderBirthCalendar();
    },

    toggleBirthCalendarYearPicker: function () {
        this.setBirthCalendarYearPicker(!this._calendarView.yearPickerOpen);
    },

    setBirthCalendarYearPicker: function (open) {
        this._calendarView.yearPickerOpen = !!open;
        const yearPanel = document.getElementById("birth_cal_year_panel");
        const monthPanel = document.getElementById("birth_cal_month_panel");
        const titleBtn = document.getElementById("birth_calendar_title");
        const prevBtn = document.getElementById("birth_cal_prev");
        const nextBtn = document.getElementById("birth_cal_next");

        if (yearPanel) yearPanel.hidden = !open;
        if (monthPanel) monthPanel.hidden = !!open;
        if (titleBtn) {
            titleBtn.setAttribute("aria-expanded", open ? "true" : "false");
            titleBtn.classList.toggle("is-year-open", !!open);
        }
        if (prevBtn) prevBtn.disabled = !!open;
        if (nextBtn) nextBtn.disabled = !!open;

        if (open) {
            this.renderBirthCalendarYearList();
        }
    },

    renderBirthCalendarYearList: function () {
        const listEl = document.getElementById("birth_cal_year_list");
        if (!listEl) return;

        const selectedYear = this._calendarView.year;
        const years = [];
        for (let y = this._calendarYearMax; y >= this._calendarYearMin; y--) {
            const isActive = y === selectedYear;
            years.push(
                `<button type="button" class="birth-cal-year-item${isActive ? " is-selected" : ""}" data-year="${y}" role="option" aria-selected="${isActive ? "true" : "false"}">${y}년</button>`
            );
        }
        listEl.innerHTML = years.join("");

        const active = listEl.querySelector(".birth-cal-year-item.is-selected");
        if (active) {
            requestAnimationFrame(() => {
                active.scrollIntoView({ block: "center", inline: "nearest" });
            });
        }
    },

    selectBirthCalendarYear: function (year) {
        const y = Number(year);
        if (!Number.isFinite(y) || y < this._calendarYearMin || y > this._calendarYearMax) return;
        this._calendarView.year = y;

        // 선택된 일자 연도만 맞추고 월/일은 유지 (말일 보정)
        const selected = this._calendarView.selectedYmd || "";
        if (/^\d{8}$/.test(selected)) {
            const month = parseInt(selected.slice(4, 6), 10);
            let day = parseInt(selected.slice(6, 8), 10);
            const maxDay = new Date(y, month, 0).getDate();
            if (day > maxDay) day = maxDay;
            this._calendarView.month = month - 1;
            this._calendarView.selectedYmd =
                String(y) +
                String(month).padStart(2, "0") +
                String(day).padStart(2, "0");
        }

        this.setBirthCalendarYearPicker(false);
        this.renderBirthCalendar();
    },

    renderBirthCalendar: function () {
        const yearLabel = document.getElementById("birth_cal_year_label");
        const monthLabel = document.getElementById("birth_cal_month_label");
        const daysEl = document.getElementById("birth_calendar_days");
        if (!daysEl) return;

        const { year, month, selectedYmd } = this._calendarView;
        if (yearLabel) yearLabel.textContent = `${year}년`;
        if (monthLabel) monthLabel.textContent = `${month + 1}월`;

        const firstDay = new Date(year, month, 1);
        const startWeekday = firstDay.getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const today = new Date();
        const todayYmd =
            String(today.getFullYear()) +
            String(today.getMonth() + 1).padStart(2, "0") +
            String(today.getDate()).padStart(2, "0");

        const cells = [];
        for (let i = 0; i < startWeekday; i++) {
            cells.push(`<button type="button" class="birth-cal-day is-empty" tabindex="-1" aria-hidden="true"></button>`);
        }

        for (let d = 1; d <= daysInMonth; d++) {
            const ymd =
                String(year) +
                String(month + 1).padStart(2, "0") +
                String(d).padStart(2, "0");
            const weekday = (startWeekday + d - 1) % 7;
            const classes = ["birth-cal-day"];
            if (weekday === 0) classes.push("is-sunday");
            if (weekday === 6) classes.push("is-saturday");
            if (ymd === todayYmd) classes.push("is-today");
            if (ymd === selectedYmd) classes.push("is-selected");
            cells.push(
                `<button type="button" class="${classes.join(" ")}" data-ymd="${ymd}" aria-label="${year}년 ${month + 1}월 ${d}일">${d}</button>`
            );
        }

        daysEl.innerHTML = cells.join("");
    },

    selectBirthCalendarDay: function (ymd) {
        if (!app._isValidDate(ymd)) return;
        this._calendarView.selectedYmd = ymd;
        this.renderBirthCalendar();
    },

    confirmBirthCalendar: function () {
        const ymd = this._calendarView.selectedYmd;
        this.closeBirthCalendar();
        if (ymd) {
            this.applyBirthDateValue(ymd, { delay: 120 });
        }
    },


    setPlanList: function (plans, upload_date) {
        this.plans = Array.isArray(plans) ? plans : [];
        this.upload_date = upload_date || {};
        this.setProductsGroupCD(); //최초 상품유형,만기 불러오기
    },

    /** 현재 성별 기준 노출 가능 플랜 */
    getVisiblePlans: function () {
        const gender = this.gender || "M";
        if (gender === "M") {
            return this.plans.filter((p) => !this.isFemaleOnlyPlan(p));
        }
        return this.plans.slice();
    },

    /** 나이 기반 기본 상품유형 */
    getDefaultPlanTypeByAge: function (age) {
        if (age <= 15) return "19"; // 어린이(무해지)
        if (age <= 40) return "20"; // 청소년(무해지)
        return "06"; // 종합(무해지)
    },

    setProductsGroupCD: function () {
        const listContainer = document.getElementById("productsgroupList");
        const selectedProductEl = document.getElementById("selected_product");
        if (!listContainer || !selectedProductEl) return;

        const age = this.insur_age;
        const visiblePlans = this.getVisiblePlans();
        const uniquePlanTypes = [...new Map(visiblePlans.map(p => [p.plan_type, p])).values()];

        listContainer.innerHTML = `<ul>${uniquePlanTypes.map(plan => `
            <li>
                <a href="#none" class="select-btn" plan_type="${plan.plan_type}" onclick="selectProduct(this)">${plan.plan_name}</a>
            </li>
        `).join('')}</ul>`;

        if (uniquePlanTypes.length === 0) {
            selectedProductEl.textContent = "상품 없음";
            selectedProductEl.removeAttribute("plan_type");
            return;
        }

        const preferredType = this.getDefaultPlanTypeByAge(age);
        let selected = uniquePlanTypes.find((p) => p.plan_type === this.plan_type)
            || uniquePlanTypes.find((p) => p.plan_type === preferredType)
            || uniquePlanTypes[0];

        // 남성인데 여성상품이 남아 있으면 교체
        if (this.gender === "M" && this.isFemaleOnlyPlan(selected)) {
            selected = uniquePlanTypes.find((p) => p.plan_type === preferredType) || uniquePlanTypes[0];
        }

        this.applySelectedPlan(selected);
        this.setPaymentExpirationCD(this.plan_type);
        this.setPlanIdByCurrentState();
    },

    applySelectedPlan: function (plan) {
        if (!plan) return;
        const selectedProductEl = document.getElementById("selected_product");
        this.plan_type = plan.plan_type;
        this.plan_name = plan.plan_name;
        this.plan_id = plan.plan_id;
        if (plan.insurance_type) {
            this.insurance_type = plan.insurance_type;
        }
        if (selectedProductEl) {
            selectedProductEl.setAttribute("plan_type", plan.plan_type);
            selectedProductEl.textContent = plan.plan_name;
        }
    },

    setPaymentExpirationCD: function (plan_type) {
        const selectedProductEl = document.getElementById("selected_product");
        const paymentContainer = document.getElementById("paymentgroupList");
        const selectedExpirationEl = document.getElementById("selected_expiration");
        if (!paymentContainer || !selectedExpirationEl) return;

        if (selectedProductEl) {
            selectedProductEl.setAttribute("plan_type", plan_type);
        }

        const filtered = this.getVisiblePlans().filter(p => String(p.plan_type) === String(plan_type));
        const uniquePayTerms = [...new Map(filtered.map(p => [p.plan_payterm_type, p])).values()];

        paymentContainer.innerHTML = `<ul>${uniquePayTerms.map(item => `
            <li>
            <a href="#none" class="select-btn" plan_payterm_type="${item.plan_payterm_type}" onclick="selectExpiration(this)">${item.plan_payterm_type_name}</a>
            </li>
        `).join('')}</ul>`;

        if (uniquePayTerms.length === 0) {
            selectedExpirationEl.textContent = "만기 없음";
            selectedExpirationEl.removeAttribute("plan_payterm_type");
            return;
        }

        let targetItem = uniquePayTerms.find((item) => String(item.plan_payterm_type) === String(this.plan_payterm_type))
            || uniquePayTerms.find((item) => String(item.plan_payterm_type_name || "").includes("20년/100세"))
            || uniquePayTerms[0];

        this.plan_payterm_type = targetItem.plan_payterm_type;
        this.plan_payterm_type_name = targetItem.plan_payterm_type_name;
        if (targetItem.insurance_type) {
            this.insurance_type = targetItem.insurance_type;
        }

        selectedExpirationEl.setAttribute("plan_payterm_type", targetItem.plan_payterm_type);
        selectedExpirationEl.textContent = targetItem.plan_payterm_type_name;
    },

    setPlanIdByCurrentState: function () {
        const matched = this.plans.find((p) =>
            String(p.plan_type) === String(this.plan_type)
            && String(p.plan_payterm_type) === String(this.plan_payterm_type)
        );
        if (!matched) return;

        this.plan_id = matched.plan_id;
        this.plan_type = matched.plan_type;
        this.plan_name = matched.plan_name;
        this.plan_payterm_type = matched.plan_payterm_type;
        this.plan_payterm_type_name = matched.plan_payterm_type_name;
        if (matched.insurance_type) {
            this.insurance_type = matched.insurance_type;
        }
    },


    setCoverageProductList: function (data) {
        //생성
        this.plan_coverages = data.plan_coverages;
        this.coverage_premiums = data.coverage_premiums;
        this.product_insur_premiums = data.product_insur_premiums;

        //console.log({ plan_coverages: this.plan_coverages, coverage_premiums: this.coverage_premiums, product_insur_premiums: this.product_insur_premiums });

        //보장
        for (var i = 0; i < this.plan_coverages.length; i++) {
            //보장 종류 선택 전체-암-뇌-심-진단..
            this.plan_coverages[i].coverages_checked = "all-checked";
        }


        //회사별 대표담보위치
        this.guide_bojang_item = new Map();

        for (var i = 0; i < this.coverage_premiums.length; i++) {
            this.coverage_premiums[i].total_premium = 0;
            for (var j = 0; j < this.coverage_premiums[i].detailList.length; j++) {

                //각 보험료
                this.coverage_premiums[i].detailList[j].color = "price-black"; //black color

                //보장 종류 선택 전체-암-뇌-심-진단..
                this.coverage_premiums[i].detailList[j].coverages_checked = "all-checked";

                //보장 항목 체크,비체크
                this.coverage_premiums[i].detailList[j].cover_selected = "checked";

                //가이드 대표담보 와 상품별 대표담보 위치를 매핑한다.
                this.guide_bojang_item.set(this.coverage_premiums[i].company_code + this.coverage_premiums[i].detailList[j].coverage_cd, j);


                //base_coverage_amount,base_premium 
                this.coverage_premiums[i].detailList[j].base_coverage_amount = this.coverage_premiums[i].detailList[j].guide_coverage_amount;
                this.coverage_premiums[i].detailList[j].base_premium = this.coverage_premiums[i].detailList[j].guide_coverage_premium;

                //합계보험료
                this.coverage_premiums[i].total_premium += Math.floor(this.coverage_premiums[i].detailList[j].guide_coverage_premium);
            }
        }

        //console.log({ plan_coverages: this.plan_coverages, coverage_premiums: this.coverage_premiums });

    },


    //모든 보장을 리셋
    resetAllCoverages: function (checked) {
        // 체크 상태에 따른 값 미리 정의
        const checkedValue = checked ? "all-checked" : "";
        const selectedValue = checked ? "checked" : "";

        // 1. 플랜 보장 리스트 일괄 처리
        this.plan_coverages.forEach(item => {
            item.coverages_checked = checkedValue;
        });

        // 2. 상품별 상세 보장 리스트 일괄 처리 (이중 루프)
        this.coverage_premiums.forEach(product => {
            product.detailList.forEach(detail => {
                detail.coverages_checked = checkedValue;
                detail.cover_selected = selectedValue;
            });
        });
    },

    //보장 종류 선택 시(전체-암-뇌-심-진단-수술-입원) coverages_checked 상태 변경
    syncCoverageSelection: function (checked) {

        // 1. 현재 활성화된 메뉴들의 value 값을 미리 배열로 추출 (매번 DOM 접근 방지)
        const activeValues = Array.from(document.querySelectorAll(".setting-category-list .item-menu-box.active")).map(el => el.getAttribute("value"));
        //console.log({ activeValues: activeValues });

        // [Helper] 보장명 매칭 로직 (수술/입원 특수 케이스 처리)
        const isMatched = (coverageName, targetVal) => {
            if (!targetVal) return false;
            if (targetVal === "수술/입원" || targetVal === "수술입원") {
                return coverageName.includes("수술") || coverageName.includes("입원");
            }
            return coverageName.includes(targetVal);
        };

        // 2. 플랜 보장 리스트 업데이트
        this.plan_coverages.forEach(item => {
            if (checked) {
                // 체크 시: 현재 선택한 값과 매칭되면 체크, 아니면 기존 'all-checked' 해제
                if (isMatched(item.coverage_name, this.checked_val)) {
                    item.coverages_checked = "checked";
                }
                else if (item.coverages_checked === "all-checked") {
                    item.coverages_checked = "";
                }
            }
            else {
                // 체크 해제 시: 남은 활성 메뉴 중 하나라도 매칭되는 게 있는지 확인
                const stillMatches = activeValues.some(val => isMatched(item.coverage_name, val));
                item.coverages_checked = stillMatches ? "checked" : "";
            }
        });

        // 3. 상품별 상세 보장 리스트 업데이트
        this.coverage_premiums.forEach(premium => {
            premium.detailList.forEach(detail => {
                if (checked) {
                    if (isMatched(detail.coverage_name, this.checked_val)) {
                        detail.coverages_checked = "checked";
                        detail.cover_selected = "checked";
                    } else if (detail.coverages_checked === "all-checked") {
                        detail.coverages_checked = "";
                        detail.cover_selected = "";
                    }
                } else {
                    const stillMatches = activeValues.some(val => isMatched(detail.coverage_name, val));
                    const state = stillMatches ? "checked" : "";
                    detail.coverages_checked = state;
                    detail.cover_selected = state;
                }
            });
        });
    },


    // 오름차순 정렬 및 랜더링
    renderPremiumAsc: function () {
        const exception_prdt = ["23", "24", "25", "26", "27", "30", "31"];
        const menuIds = ["all", "cancer", "brain", "heart", "diagnosis", "surgery"];
        const productListContainer = document.getElementById("productList");
        const lowPremiumRadio = document.getElementById("low_premium");

        // 1. 예외 상품유형 코드에 따른 메뉴 비활성화 제어
        const isException = exception_prdt.includes(this.plan_type);

        menuIds.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.pointerEvents = isException ? "none" : "";
        });

        if (isException) {
            this.sync_opacity();
        }
        else {
            this.reset_opacity();
        }

        // 2. 보험료 오름차순 정렬 (기존 코드보다 간결하게)
        this.coverage_premiums.sort((a, b) => a.total_premium - b.total_premium);

        // 3. 최소/최대 보험료를 가진 회사 코드 추출 (색상 표시용)
        let min_pos = 0;
        let max_pos = 0;
        if (this.coverage_premiums.length > 0) {
            min_pos = this.coverage_premiums[0].company_code;
            max_pos = this.coverage_premiums[this.coverage_premiums.length - 1].company_code;
        }

        // 4. 라디오 버튼 체크 상태 변경
        if (lowPremiumRadio) lowPremiumRadio.checked = true;

        // 5. 리스트 HTML 생성 및 렌더링
        const listHTML = `<ul>${this.coverage_premiums.map((item, index) => {
            const class_attr = item.company_code === min_pos ? "price-blue" : item.company_code === max_pos ? "price-red" : "price-black";
            const formattedPremium = item.total_premium.toLocaleString() + "원";
            const companyName = item.company_name || item.product_name || "";

            return `
            <li>
                <a href="javascript:popupOpen('detail','${item.company_code}')" class="item-wrap">
                    <div class="rank-box">${index + 1}</div>
                    <div class="img-box">
                        <img src="./img/${item.company_code}.png" alt="${companyName || "보험사"}">
                    </div>
                    <div class="info-box">
                        ${companyName ? `<div class="company-name">${companyName}</div>` : ""}
                        <div class="${class_attr}" company_code="${item.company_code}">
                            ${formattedPremium}
                        </div>
                    </div>
                </a>
            </li>
        `;
        }).join('')}</ul>`;

        productListContainer.innerHTML = listHTML;
    },

    //내림차순 정렬 및 랜더링
    renderPremiumDesc: function () {
        const productListContainer = document.getElementById("productList");
        if (!productListContainer) return;

        const a_href_name = "detail";

        // 1. 보험료 내림차순 정렬 (높은 금액이 위로)
        this.coverage_premiums.sort((a, b) => b.total_premium - a.total_premium);

        //console.log({ coverage_premiums: this.coverage_premiums });


        // 2. 색상 처리를 위한 최저/최고가 위치 파악
        let min_pos = 0;
        let max_pos = 0;

        if (this.coverage_premiums.length > 0) {
            // 내림차순이므로 0번째가 최고가(max), 마지막이 최저가(min)
            max_pos = this.coverage_premiums[0].company_code;
            min_pos = this.coverage_premiums[this.coverage_premiums.length - 1].company_code;
        }

        // 3. 리스트 HTML 생성 (Template Literal 활용)
        const listHTML = `<ul>${this.coverage_premiums.map((item, index) => {
            const class_attr = item.company_code === min_pos ? "price-blue" : item.company_code === max_pos ? "price-red" : "price-black";
            const formattedPremium = item.total_premium.toLocaleString() + "원";
            const companyName = item.company_name || item.product_name || "";

            return `
            <li>
                <a href="javascript:popupOpen('${a_href_name}','${item.company_code}')" class="item-wrap">
                    <div class="rank-box">${index + 1}</div>
                    <div class="img-box">
                        <img src="./img/${item.company_code}.png" alt="${companyName || "보험사"}">
                    </div>
                    <div class="info-box">
                        ${companyName ? `<div class="company-name">${companyName}</div>` : ""}
                        <div class="${class_attr}" company_code="${item.company_code}">
                            ${formattedPremium}
                        </div>
                    </div>
                </a>
            </li>
        `;
        }).join('')}</ul>`;

        productListContainer.innerHTML = listHTML;
    },



    reset_menu: function () {
        // 1. 메뉴 활성화 상태 초기화
        document.querySelectorAll(".item-menu-box").forEach(el => el.classList.remove("active"));
        document.getElementById("all")?.classList.add("active");

        // 2. 화면에서 숨길 요소들 일괄 처리 (display: none)
        const hideSelectors = ["article.popup3", ".mt40", ".list-filter-layout1", ".result-list-layout1"];
        hideSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => el.style.display = "none");
        });

        // 3. 클릭 방지(pointer-events) 적용할 ID들
        const disablePointerIds = ["all", "cancer", "brain", "heart", "diagnosis", "surgery", "change-bojang"];
        disablePointerIds.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.pointerEvents = "none";
        });

        // 4. '보장 변경' 버튼 비활성화
        const changeBojangBtn = document.getElementById("change-bojang");
        if (changeBojangBtn) {
            changeBojangBtn.disabled = true;
        }
    },

    sync_menu_display: function () {
        // 1. 개별 요소 및 클래스 요소 노출 (인라인 display 제거 → CSS 기본값)
        const selectorsToBlock = ['article.popup3', '.mt40', '.list-filter-layout1', '.result-list-layout1'];
        selectorsToBlock.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => { el.style.display = ""; });
        });

        // 2. 보장 항목(암, 뇌, 심 등)의 style 속성 일괄 제거
        const menuIds = ["all", "cancer", "brain", "heart", "diagnosis", "surgery"];
        menuIds.forEach(id => {
            document.getElementById(id)?.removeAttribute("style");
        });

        // 3. '보장 변경' 버튼 활성화 및 스타일 조정
        const changeBojangBtn = document.getElementById("change-bojang");
        if (changeBojangBtn) {
            changeBojangBtn.style.pointerEvents = "";
            changeBojangBtn.disabled = false;
        }
    },

    reset_opacity: function () {
        // 1. 초기화할 대상 ID들을 배열로 정의합니다.
        const menuIds = ["all", "cancer", "brain", "heart", "diagnosis", "surgery"];

        // 2. 루프를 돌며 스타일(opacity)을 제거합니다.
        menuIds.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                // 빈 문자열("")을 할당하면 인라인 스타일이 제거되어 CSS 기본값으로 돌아갑니다.
                el.style.opacity = "";
            }
        });
    },


    sync_opacity: function () {
        // 1. 대상 ID들을 배열로 관리합니다.
        const menuIds = ["all", "cancer", "brain", "heart", "diagnosis", "surgery"];

        // 2. 루프를 돌며 스타일을 한꺼번에 적용합니다.
        menuIds.forEach(id => {
            const el = document.getElementById(id);
            if (el) {
                el.style.opacity = "0.2";
            }
        });
    },


    show_spinner: function () {
        // Show loader when the content is loading
        document.querySelector('.loader-container').style.display = 'flex';
        // Simulate some asynchronous operation (e.g., API request)
    },

    hide_spinner: function () {
        setTimeout(function () {
            // Hide loader when the content has loaded
            document.querySelector('.loader-container').style.display = 'none';
        }, 300); // Replace 500 with the time it takes to load your content
    },

    /** 조회 버튼/자동조회 공통 진입점 */
    prepareAndSearch: function () {
        const changeBojangBtn = document.getElementById("change-bojang");
        const allProductEl = document.getElementById("all-product");
        const allEl = document.getElementById("all");

        this.set_calculate_age();

        if (!app._isValidDate(this.birth_date)) {
            if (changeBojangBtn) changeBojangBtn.disabled = true;
            this.sync_opacity();
            return false;
        }

        if (changeBojangBtn) changeBojangBtn.disabled = false;

        document.querySelectorAll(".setting-category-list .item-menu-box").forEach(item => {
            item.classList.remove("active");
        });
        allProductEl?.classList.add("active");
        allEl?.classList.add("active");

        this.reset_opacity();
        this.setPlanIdByCurrentState();
        this.onClickSearch();
        return true;
    },

    /**
     * 조건 변경 시 자동 조회 (디바운스)
     * @param {{ delay?: number, requireValidBirth?: boolean }} options
     */
    scheduleAutoSearch: function (options = {}) {
        const delay = typeof options.delay === "number" ? options.delay : 220;
        const requireValidBirth = options.requireValidBirth !== false;

        if (this._autoSearchTimer) {
            clearTimeout(this._autoSearchTimer);
            this._autoSearchTimer = null;
        }

        this._autoSearchTimer = setTimeout(() => {
            this._autoSearchTimer = null;
            if (!this.jwt && !this.resolveAuthToken()) return;
            if (requireValidBirth && !app._isValidDate(this.birth_date)) return;
            if (!this.plan_id) {
                this.setPlanIdByCurrentState();
            }
            if (!this.plan_id) return;
            this.prepareAndSearch();
        }, delay);
    },

};




$(document).ready(function () {

    state.set_calculate_age();
    state.init();

    // 생년월일 입력 이벤트
    document.getElementById('birth_date').addEventListener("input", function (e) {
        const birth_date = String(e.target.value || "").replace(/\D/g, "").slice(0, 8);
        e.target.value = birth_date;
        state.applyBirthDateValue(birth_date, { delay: 380 });
    });

    // 커스텀 캘린더 모달
    const birthCalBtn = document.getElementById("birth_calendar_btn");
    const birthCalModal = document.getElementById("birth_calendar_modal");
    if (birthCalBtn) {
        birthCalBtn.addEventListener("click", function () {
            state.openBirthCalendar();
        });
    }
    if (birthCalModal) {
        birthCalModal.addEventListener("click", function (e) {
            if (e.target.closest("[data-calendar-close]")) {
                state.closeBirthCalendar();
                return;
            }
            const yearBtn = e.target.closest(".birth-cal-year-item[data-year]");
            if (yearBtn) {
                state.selectBirthCalendarYear(yearBtn.getAttribute("data-year"));
                return;
            }
            const dayBtn = e.target.closest(".birth-cal-day[data-ymd]");
            if (dayBtn) {
                state.selectBirthCalendarDay(dayBtn.getAttribute("data-ymd"));
            }
        });
    }
    document.getElementById("birth_calendar_title")?.addEventListener("click", function () {
        state.toggleBirthCalendarYearPicker();
    });
    document.getElementById("birth_cal_prev")?.addEventListener("click", function () {
        state.shiftBirthCalendarMonth(-1);
    });
    document.getElementById("birth_cal_next")?.addEventListener("click", function () {
        state.shiftBirthCalendarMonth(1);
    });
    document.getElementById("birth_cal_today")?.addEventListener("click", function () {
        const now = new Date();
        state._calendarView.year = now.getFullYear();
        state._calendarView.month = now.getMonth();
        state.setBirthCalendarYearPicker(false);
        state.renderBirthCalendar();
    });
    document.getElementById("birth_cal_confirm")?.addEventListener("click", function () {
        state.confirmBirthCalendar();
    });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && birthCalModal && !birthCalModal.hidden) {
            if (state._calendarView.yearPickerOpen) {
                state.setBirthCalendarYearPicker(false);
            } else {
                state.closeBirthCalendar();
            }
        }
    });

    // 성별 라디오 버튼 이벤트 연결
    document.querySelectorAll('input[type="radio"][name="gender"]').forEach(radio => {
        radio.addEventListener('change', function () {
            state.reset_menu();
            state.gender = this.value;
            // 성별 변경 시 상품 목록(여성전용 등) 재구성
            state.setProductsGroupCD();
            state.setPlanIdByCurrentState();
            state.scheduleAutoSearch({ delay: 180 });
        });
    });

    // 조회하기 / 다시 조회
    document.getElementById("product-retrieve").addEventListener("click", function () {
        if (!app._isValidDate(state.birth_date)) {
            alert("생년월일을 확인해주세요.");
            return;
        }
        state.prepareAndSearch();
    });

    // 보험료 정렬 라디오 버튼 이벤트 연결
    document.querySelectorAll('input[type="radio"][name="filter"]').forEach(radio => {
        radio.addEventListener('change', function (e) {
            const change_premium = e.target.value;

            if (change_premium === "low_premium") {
                state.renderPremiumAsc();
            }
            else if (change_premium === "high_premium") {
                state.renderPremiumDesc();
            }
        });
    });

});


// 이벤트 위임 방식을 사용하여 클릭 이벤트 처리
document.addEventListener("click", function (e) {
    // 1. 클릭된 요소가 .item-menu-box인지 확인 (상위 요소 포함)
    const target = e.target.closest(".setting-category-list .item-menu-box");
    if (!target) return;

    // 2. 현재 상태값 추출
    const checked = target.classList.contains("active");
    const rawText = target.innerText;

    // "진단" -> "진단비" 매핑 및 공백 제거 (trim 활용)
    const checked_insur_val = (rawText === "진단" ? "진단비" : rawText).trim();

    // 3. 상태(state) 업데이트
    state.checked_val = checked_insur_val;

    // 4. 로직 분기 처리
    if (checked && state.checked_val === "전체") {
        // [케이스 1] '전체' 카테고리가 활성화된 경우
        state.resetAllCoverages(checked);
        product_detail.recalculateTotalPremiumBySelection();

        state.renderPremiumAsc();
    }
    else {
        // [케이스 2] '전체'가 아니거나, 체크 해제된 경우 (중복 로직 통합)
        product_detail.insur_HTML = "";

        // 상태 설정
        state.syncCoverageSelection(checked);
        product_detail.recalculateTotalPremiumBySelection();

        // HTML 생성 및 렌더링
        product_detail.insur_HTML += product_detail.generateCoverageListHTML();

        const detailContainer = document.getElementById("allProductsDetailList");
        if (detailContainer) {
            detailContainer.innerHTML = product_detail.insur_HTML;
        }
        state.renderPremiumAsc();
    }
});
